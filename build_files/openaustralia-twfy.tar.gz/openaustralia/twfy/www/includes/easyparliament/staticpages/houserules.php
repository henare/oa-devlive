<dl>
<dt>Contributions must be civil and tasteful</dt>
<dd><p>Please be nice to each other. Please respect Representatives and Senators. If you think they have an easy job, you're very, very wrong.</p></dd>

<dt>Please be patient</dt>
<dd><p>Users of all ages and abilities may be contributing to OpenAustralia. Also, remember this site is run by volunteers, so please bear with us if we&rsquo;re slow to get back to you.</p></dd>

<dt>No disruptive, offensive or abusive behaviour</dt>
<dd><p>Contributions should be constructive and polite, not mean-spirited or contributed with the intention of causing trouble. </p></dd>

<dt>No unlawful or objectionable content</dt>
<dd><p>Unlawful, harassing, defamatory, abusive, threatening, harmful, obscene, profane, sexually oriented, racially offensive or otherwise objectionable material is not acceptable. </p></dd>

<dt>No spamming or off-topic material</dt>
<dd><p>We don't allow the submission of the same or very similar contributions many times. Please don't re-submit your comment to more than one discussion.</p></dd>

<dt>No advertising</dt>
<dd><p>At all. Ever. Even subtle stuff.</p></dd>

<dt>Please use your own name if you can</dt>
<dd><p>We'd prefer you to use your real name, but understand that for some people this won't be an option &ndash; the name you choose will be displayed on the site.</p></dd>

<dt>Don't impersonate others</dt>
<dd><p>They tend to get cross. As do we.</p></dd>
 
<dt>Please don't link to websites you wouldn't want your granny to visit</dt>
<dd><p>No porn, no snuff, no filez etc.</p></dd>

<dt>Deliberate misuse of the "report this comment" complaints system is not permitted</dt>
<dd><p>If you persist in doing this action may be taken against your account. It's bad form.</p></dd>

<dt>Break these House Rules once, and we'll let you off with a warning.</dt>
<dd><p>After that, we reserve the right to get medieval.</p></dd>
</dl>
