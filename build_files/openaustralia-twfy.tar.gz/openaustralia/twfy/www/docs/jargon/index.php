<?php

$this_page = "glossary";

include_once "../../includes/easyparliament/init.php";

$PAGE->page_start();

?>

<h4>A subheading</h4>

<p>Lots of glossary things and more code here.</p>


<?php

$PAGE->page_end();

?>