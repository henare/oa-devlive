#!/bin/bash
# ============================================================================
# Script for creating appliances exported from SUSE Studio
# (http://susestudio.com) on your local system.
#
# Requires kiwi (http://kiwi.berlios.de/).
#
# Contact: feedback@susestudio.com
# ============================================================================

# ----------------------------------------
# Prints and runs the given command. 
# Aborts if the command fails. 
# ----------------------------------------
function run_cmd {
  command=$1
  logfile=$2
  echo $command
  $command
  if [ $? -ne 0 ]; then
    echo
    echo "** Appliance creation failed!"
    if [ "$logfile" != '' ]; then
      echo "See $logfile for details."
    fi
    exit 1
  fi
}

# ----------------------------------------
# Displays usage help.
# ----------------------------------------
function usage {
  echo >&2 "Usage:"
  echo >&2 "  create_appliance.sh [--skip-custom-boot-image]"
}

# ----------------------------------------
# Parse command line options.
# ----------------------------------------
skip_custom_boot_image=
while [ $# -gt 0 ]; do
  case "$1" in
    --skip-custom-boot-image) skip_custom_boot_image=true;;
    -*) usage; exit 1;;
    *) break;;
  esac
  shift
done

# ----------------------------------------
# We need to run as root
# ----------------------------------------
if [ `whoami` != 'root' ]; then
  echo "Please run this script as root."
  exit 1
fi

# ----------------------------------------
# Check that kiwi is installed
# ----------------------------------------
kiwi=`which kiwi 2> /dev/null`
if [ $? -ne 0 ]; then
  echo "Kiwi is required but not found on your system."
  echo "Run the following command to install kiwi:"
  echo
  echo "  zypper install kiwi kiwi-tools kiwi-desc-* kiwi-doc"
  echo
  exit 1
fi

# ----------------------------------------
# Check kiwi version
# ----------------------------------------
kiwi_ver='kiwi-3.01-137.1'
installed_kiwi_ver=`rpm -q kiwi`
if [ "$installed_kiwi_ver" != "$kiwi_ver" ]; then
  echo "'$kiwi_ver' expected, but '$installed_kiwi_ver' found."
  while true; do
    read -p "Continue? [y/n] " yn
    case $yn in
      [Yy]* ) break;;
      [Nn]* ) exit;;
    esac
  done
fi

# ----------------------------------------
# Check architecture (i686, x86_64)
# ----------------------------------------
image_arch='i686'
sys_arch=`uname -m`
linux32=`which linux32 2>/dev/null`
if [ "$image_arch" = 'i686' ] && [ "$sys_arch" = 'x86_64' ]; then
  if [ "$linux32" = '' ]; then
    echo "'linux32' is required but not found."
    exit 1
  else
    kiwi="$linux32 $kiwi"
  fi
elif [ "$image_arch" = 'x86_64' ] && [ "$sys_arch" = 'i686' ]; then
  echo "Cannot build $image_arch image on a $sys_arch machine."
  exit 1
fi

# ----------------------------------------
# Replace internal repositories in 
# config.xml.
# ----------------------------------------
echo "** Checking for internal repositories..."
for repo in "henare openSUSE 11.1"; do
  # check if the repos are already replaced
  update_repo=0
  for dir in 'bootsource' 'source'; do
    grep -q "{$repo}" $dir/config.xml && update_repo=1
  done

  if [ $update_repo -eq 1 ]; then
    # prompt for repo url
    read -p "Enter repository URL for '$repo': " url
    escaped_url=`echo "$url" | sed -e 's/\//\\\\\//g'`
    for dir in 'bootsource' 'source'; do
      # backup config.xml first
      if [ ! -f $dir/config.xml.bak ]; then
        cp $dir/config.xml $dir/config.xml.bak
        echo "  -> Backed up $dir/config.xml to $dir/config.xml.bak"
      fi
      sed -i "s/{$repo}/$escaped_url/g" $dir/config.xml
    done
  fi
done

# ----------------------------------------
# Use pigz (parallel gzip), if available
# ----------------------------------------
pigz="--gzip-cmd `which pigz 2>/dev/null`"
[ $? -ne 0 ] && pigz=

# ----------------------------------------
# Create boot image (with custom theming)
# ----------------------------------------
if [ ! "$skip_custom_boot_image" ]; then
  echo
  echo "** Creating custom boot image (initrd)..."
  run_cmd "rm -rf bootbuild/root bootimage/initrd"
  run_cmd "mkdir -p bootbuild bootimage/initrd"
  run_cmd "$kiwi --prepare bootsource \
                 --root bootbuild/root \
                 --logfile boot-prepare.log \
                 $pigz" "boot-prepare.log"
  run_cmd "$kiwi --create bootbuild/root \
                 -d bootimage/initrd \
                 --logfile boot-create.log \
                 $pigz" "boot-create.log"
fi

# ----------------------------------------
# Create appliance with custom initrd
# ----------------------------------------
echo
echo "** Creating appliance..."
run_cmd "rm -rf build/root"
run_cmd "mkdir -p build image"
run_cmd "$kiwi --prepare source \
               --root build/root \
               --logfile prepare.log \
               $pigz" "prepare.log"
run_cmd "$kiwi --create build/root \
               -d image \
               --prebuiltbootimage bootimage/initrd \
               --logfile create.log \
               $pigz" "create.log"

# ----------------------------------------
# And we're done!
# ----------------------------------------
image_file="image/OpenAustralia_DevLive.i686-0.0.5.vmdk"
echo
echo "** Appliance created successfully! ($image_file)"
echo "To boot the image using qemu-kvm, run the following command:"
echo "  qemu-kvm -snapshot -m 512 $image_file &"
echo
