<?php
// This sidebar is on the pages that show all the text of a particular debate.

$this->block_start(array(
	'id'=>'help', 
	'title'=>"What is the Scottish Parliament?",
	'url'=>'/sp/#help',
	'body'=>false
));
$this->block_end();
?>
