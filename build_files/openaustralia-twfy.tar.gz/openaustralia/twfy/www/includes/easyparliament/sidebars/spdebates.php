<?php

$URL = new URL('help');
$helpurl = $URL->generate();
$this->block_start(array('id'=>'help', 'title'=>"What is the Scottish Parliament?"));
?>

<?php
$this->block_end();
?>
