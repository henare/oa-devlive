#!/bin/bash
#================
# FILE          : config.sh
#----------------
# PROJECT       : OpenSuSE KIWI Image System
# COPYRIGHT     : (c) 2006 SUSE LINUX Products GmbH. All rights reserved
#               :
# AUTHOR        : Marcus Schaefer <ms@suse.de>
#               :
# BELONGS TO    : Operating System images
#               :
# DESCRIPTION   : configuration script for SUSE based
#               : operating systems
#               :
#               :
# STATUS        : BETA
#----------------
#======================================
# Functions...
#--------------------------------------
test -f /.kconfig && . /.kconfig
test -f /.profile && . /.profile

# kiwi doesn't copy /.kconfig from source to build dir
test -f /kconfig && . /kconfig 

#======================================
# Greeting...
#--------------------------------------
echo "Configure image: [$name]..."

#======================================
# SuSEconfig
#--------------------------------------
echo "** Running suseConfig..."
suseConfig

echo "** Running ldconfig..."
/sbin/ldconfig

#======================================
# Umount kernel filesystems
#--------------------------------------
echo "** Running baseCleanMount..."
baseCleanMount

#======================================
# Clean up kconfig
#--------------------------------------
echo "** Removing kconfig..."
rm /kconfig


#======================================
# Firewall Configuration
#--------------------------------------
echo '** Configuring firewall...'
chkconfig SuSEfirewall2_init on
chkconfig SuSEfirewall2_setup on


#=====================================
# setting kdm theme to studio
#-------------------------------------
echo '** Setting kdm theme...'
sed -i 's/DISPLAYMANAGER_KDM_THEME=.*/DISPLAYMANAGER_KDM_THEME=studio/g' /etc/sysconfig/displaymanager

#=====================================
# make the xdm theme a little bit prettier
#-------------------------------------

if [ -e /etc/X11/Xresources ]
then
  echo "xlogin*greeting: Login"                    >> /etc/X11/Xresources
  echo "xlogin*namePrompt: Name: "              >> /etc/X11/Xresources
  echo "xlogin*passwdPrompt: Password: "        >> /etc/X11/Xresources
  echo "xlogin*fail: Failed!"                      >> /etc/X11/Xresources
  echo "xlogin.Login.greetFont: 9x15bold"          >> /etc/X11/Xresources
  echo "xlogin.Login.promptFont: 6x13bold"         >> /etc/X11/Xresources
  echo "xlogin.Login.font: 6x13"                   >> /etc/X11/Xresources
  echo "xlogin.Login.failFont: 6x13"               >> /etc/X11/Xresources
  echo "xlogin*geometry: 300x200"                  >> /etc/X11/Xresources
  echo "xlogin*borderWidth: 1"                     >> /etc/X11/Xresources
  echo "xlogin*frameWidth: 0"                      >> /etc/X11/Xresources
  echo "xlogin*innerFramesWidth: 0"                >> /etc/X11/Xresources
  echo "xlogin*shdColor: black"                    >> /etc/X11/Xresources
  echo "xlogin*hiColor: black"                     >> /etc/X11/Xresources
  echo "xlogin*greetColor: white"                  >> /etc/X11/Xresources
  echo "xlogin*failColor: red"                     >> /etc/X11/Xresources
  echo "xlogin*promptColor: grey75"                >> /etc/X11/Xresources
  echo "xlogin*foreground: grey75"                 >> /etc/X11/Xresources
  echo "xlogin*background: black"                  >> /etc/X11/Xresources
  echo "xlogin*borderColor: grey50 "               >> /etc/X11/Xresources
fi

if [ -e /etc/icewm/preferences ]
then
  sed -i 's#DesktopBackgroundImage=.*#DesktopBackgroundImage="/etc/X11/xdm/BackGround.xpm"#' /etc/icewm/preferences 
fi
if [ -e /etc/X11/xdm/Xsetup ]
then
  sed -i 's#^exit 0$#kill `cat /var/run/xconsole.pid`;/sbin/startproc /usr/bin/icewmbg || /usr/bin/xsetroot -solid lightgray;\nexit 0#g' /etc/X11/xdm/Xsetup 
fi


sed --in-place -e 's/icewm/icewm-session/' /usr/bin/wmlist

sed --in-place -e 's/# solver.onlyRequires.*/solver.onlyRequires = true/' /etc/zypp/zypp.conf

#======================================
# Setting up overlay files
#--------------------------------------
echo '** Setting up overlay files...'
echo mkdir -p "/srv/www"
mkdir -p "/srv/www"
echo tar xfp "/image/f5fe3a74da3bcea2fbd980584099cc38" -C "/srv/www"
tar xfp "/image/f5fe3a74da3bcea2fbd980584099cc38" -C "/srv/www"
echo rm "/image/f5fe3a74da3bcea2fbd980584099cc38"
rm "/image/f5fe3a74da3bcea2fbd980584099cc38"
echo mkdir -p "/srv/www"
mkdir -p "/srv/www"
echo tar xfp "/image/d14af09b6493a29fd9872101910c98d8" -C "/srv/www"
tar xfp "/image/d14af09b6493a29fd9872101910c98d8" -C "/srv/www"
echo rm "/image/d14af09b6493a29fd9872101910c98d8"
rm "/image/d14af09b6493a29fd9872101910c98d8"
echo mkdir -p "/"
mkdir -p "/"
echo tar xfp "/image/5d75552b5fa51b2f68438b0dfdaed58b" -C "/"
tar xfp "/image/5d75552b5fa51b2f68438b0dfdaed58b" -C "/"
echo rm "/image/5d75552b5fa51b2f68438b0dfdaed58b"
rm "/image/5d75552b5fa51b2f68438b0dfdaed58b"
chown root:root "/etc/sysconfig/apache2"
chmod 644 "/etc/sysconfig/apache2"
chown root:root "/usr/lib/firefox/defaults/profile/bookmarks.html"
chmod 644 "/usr/lib/firefox/defaults/profile/bookmarks.html"
chown root:root "/usr/lib/firefox/browserconfig.properties"
chmod 644 "/usr/lib/firefox/browserconfig.properties"
chown root:root "/etc/apache2/vhosts.d/dev.openaustralia.org.au.conf"
chmod 644 "/etc/apache2/vhosts.d/dev.openaustralia.org.au.conf"
chown wwwrun:www "/srv/www/openaustralia/twfy/conf/general"
chmod 644 "/srv/www/openaustralia/twfy/conf/general"
chown root:root "/etc/hosts"
chmod 644 "/etc/hosts"
chown root:nobody "/etc/php5/apache2/php.ini"
chmod 644 "/etc/php5/apache2/php.ini"
chown root:root //build-custom
chmod +x //build-custom
mkdir /studio
cp /image/.profile /studio/profile
cp /image/config.xml /studio/config.xml
true
#======================================
# Configure MySQL database
#--------------------------------------

wait_for_socket()
{
  local i
  for((i=0; i<150; i++)); do
    sleep 0.2
    test -S $1 && i='' && break
  done
  test -z "$i" || return 1
  return 0
}

# ----------------------
# Config database 
# ----------------------

# Set the hostname for MySQL setup
hostname linux

# Install basic MySQL tables
echo "## Initializing MySQL databases and tables..."
mysql_install_db --user=mysql

# Start MySQL without networking
echo "## Starting MySQL..."
mysqld_safe --skip-networking --user=mysql --pid-file=/tmp/mysqld.pid &>/dev/null &
socket=/var/lib/mysql/mysql.sock
wait_for_socket $socket || {
  echo "## warning: $socket didn't appear within 30 seconds"
}

# Load MySQL data dump if it exists
if [ -f /tmp/mysql_dump.sql ]; then
  echo "## Loading MySQL data dump..."
  mysql -u root < /tmp/mysql_dump.sql 2>&1
else
  echo "## No MySQL data dump found, skipping" 
fi

# Set up users and permissions
echo "## Setting up MySQL users and permissions..."
mysql -u root < /tmp/mysql_config.sql 2>&1

# Stop MySQL service. Only needed when not in containment.
echo "## Stopping MySQL..."
kill -TERM `cat /tmp/mysqld.pid`

# Clean up temp files
rm -f /tmp/mysql_config.sql /tmp/mysql_dump.sql /tmp/mysqld.pid

# Auto-start mysql
echo "## Configuring MySQL to auto-start on boot..."
chkconfig mysql on

echo "## MySQL configuration complete"
