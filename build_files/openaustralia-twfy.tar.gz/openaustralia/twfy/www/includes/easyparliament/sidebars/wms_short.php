<?php
// This sidebar is on the pages that show all the text of a particular written answer.

$this->block_start(array(
	'id'=>'help',
	'title'=>"What are written ministerial statements?",
	'url'=>'/wms/#help',
	'body'=>false
));

$this->block_end();
?>
