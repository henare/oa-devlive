<ul>
<li><a href="#nontechie">I'd like to help out, but I'm not really a Techie.</a></li>
<li><a href="#knowsphp">I know PHP and HTML and stuff like that.</a></li>
<li><a href="#knowsruby">I know Ruby and I can write parsers, can I help you crunch the source data?<a></li>
</ul>

<br>

<!-- start new faq entry-->
<dl>

<dt><a name="nontechie"></a>I'd like to help out, but I'm not really a Techie.</dt>
<dd><p>There's a load of things you can do. Blog about us, tell your friends about OpenAustralia, leave a comment, or add a glossary entry.</p>
</dd>
<!-- end old faq entry -->
</dl>

<!-- start new faq entry-->
<dl>

<dt><a name="knowsphp"></a>I know PHP and HTML and stuff like that.</dt>
<dd><p>Great, check out <a href="http://software.openaustralia.org/">web application source<a>.</p>
</dd>
<!-- end old faq entry -->
</dl>

<!-- start new faq entry-->
<dl>

<dt><a name="knowsruby"></a>I know Ruby and I can write parsers, can I help you crunch the source data?</dt>
<dd><p>You sure can. Check out the <a href="http://software.openaustralia.org/">parser source code</a> and let us know what you want to add.</p>
</dd>
<!-- end old faq entry -->
</dl>


