# mysql script for setting database users and permissions
CREATE USER 'openaustralia'@'localhost' IDENTIFIED BY 'openaustralia';
GRANT ALL ON openaustralia.* TO 'openaustralia'@'localhost';
FLUSH PRIVILEGES;
