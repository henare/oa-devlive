<?php

$this_page = "how";

include_once "../../includes/easyparliament/init.php";

$PAGE->page_start();

?>

<h4>And as for the Lords...</h4>

<p>The mysteries of parliament explained in simple text for all.</p>


<?php

$PAGE->page_end();

?>