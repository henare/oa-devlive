<?php
$COMMENTLIST = new COMMENTLIST;
$COMMENTLIST->display('recent', array('num'=>10));
?>
