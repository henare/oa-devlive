<?php
$this->block_start(array('id'=>'help', 'title'=>"What's all this about?"));
?>

<p>This is the summary page for a Bill that is going or has gone through Parliament.
</p>

<?php
$this->block_end();
