<h2>Contact the OpenAustralia team</h2>
<p/>
<p>
Please tell us what you think about <strong>OpenAustralia.org</strong>
</p>
<ul>
<li>Did it work?</li>
<li>Do you like it? </li>
<li>How can we improve it? </li>
</ul> 
<p>
We seek responses to all these questions.
</p>
<p>The email address of OpenAustralia.org, which is run by a group of <strong>volunteers</strong>, is: <a href="mailto:<?php echo str_replace('@', '&#64;', CONTACTEMAIL); ?>"><?php echo str_replace('@', '&#64;', CONTACTEMAIL); ?></a></p>
