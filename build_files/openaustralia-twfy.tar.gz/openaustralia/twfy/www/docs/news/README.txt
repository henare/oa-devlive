To update the site news, edit editme.php.
