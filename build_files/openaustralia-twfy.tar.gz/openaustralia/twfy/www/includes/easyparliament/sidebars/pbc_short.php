<?php
// This sidebar is on the pages that show all the text of a particular debate.

$this->block_start(array(
	'id'=>'help', 
	'title'=>"What are Public Bill Committees?", 
	'url'=>'/bills/#help',
	'body'=>false
));
$this->block_end();
?>
