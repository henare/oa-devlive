<?php
// For displaying the Hansard search results.

// Remember, we are currently within the HANSARDLIST class,
// in the render() function.

twfy_debug("TEMPLATE", "hansard_search.php");

api_output($data);

?>
